awk 'BEGIN{FS=":"; OFS=":"} {print($5, $0)}' $1 | sort | awk 'BEGIN{FS=":"; OFS=":"} {print($2, $3, $4, $5, $6, $7, $8)}'
