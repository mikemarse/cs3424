#!/usr/bin/env python3
import os
import sys
import glob
import re
import shutil

directory = sys.argv[1]
template = sys.argv[2]
date = sys.argv[3]
output = sys.argv[4]
emails = {}
files = []

if not os.path.isdir(output):
    os.mkdir(output)

with open(template, 'r') as infile:
    test = infile.read()


apt_files = glob.glob(directory+"/"+"*.apt")
for i in range(len(apt_files)):
    new_file = apt_files[i].split("/")
    idx = len(new_file)
    apt_files[i] = new_file[idx-1]


for file in apt_files:
    with open(directory+"/"+file, "r") as infile:
        line = infile.readlines()
        comp = line[2]
        if int(comp) > 0:
            apt_number = file.strip(".apt")
            temp1 = line[0].strip().split(" ", 1)
            temp2 = line[1].strip().split(" ", 1)
            temp3 = line[2].strip().split(" ", 1)
            first_name = temp1[0]
            last_name = temp1[1]
            lease_start = temp2[0]
            lease_end = temp2[1]
            balance = temp3[0]

            if len(sys.argv) == 5:
                temporary = test
                temporary = re.sub(r"<<apt_number>>", apt_number, temporary)
                temporary = re.sub(r"<<date>>", date, temporary)
                temporary = re.sub(r"<<first_name>>", first_name, temporary)
                temporary = re.sub(r"<<last_name>>", last_name, temporary)
                temporary = re.sub(r"<<balance>>", balance, temporary)
                temporary = re.sub(r"<<lease_start>>", lease_start, temporary)
                temporary = re.sub(r"<<lease_end>>", lease_end, temporary)
            else:
                opn = sys.argv[5]
                cls = sys.argv[6]
                #print(apt_number)
                #print(first_name)
                temporary = test
                temporary = re.sub(re.escape(opn)+r"apt_number"+re.escape(cls), apt_number, temporary)
                temporary = re.sub(re.escape(opn)+r"date"+re.escape(cls), date, temporary)
                temporary = re.sub(re.escape(opn)+r"first_name"+re.escape(cls), first_name, temporary)
                temporary = re.sub(re.escape(opn)+r"last_name"+re.escape(cls), last_name, temporary)
                temporary = re.sub(re.escape(opn)+r"balance"+re.escape(cls), balance, temporary)
                temporary = re.sub(re.escape(opn)+r"lease_start"+re.escape(cls), lease_start, temporary)
                temporary = re.sub(re.escape(opn)+r"lease_end"+re.escape(cls), lease_end, temporary)

            if last_name in emails:
                emails[last_name] += 1
                email = last_name.replace(" ", "_")+str(emails[last_name])+".mail"
            else:
                emails[last_name] = 0
                email = last_name.replace(" ", "_")+".mail"

            with open(output+"/"+email, "w") as outfile:
                outfile.write(temporary)
                
