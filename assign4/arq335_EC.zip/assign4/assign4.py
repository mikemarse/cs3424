#!/usr/bin/env python3
import os
import sys
import glob
import re
import shutil

list = []
dictionary = {}
pattern = r"(proj\w+)\.[a-zA-Z]*"

def organize():
    test = glob.glob(sys.argv[1]+"/proj")+glob.glob(sys.argv[1]+"/proj.*")
    for i in range(len(test)):
        temp = test[i]
        temp2 = temp.split("/")
        indexTemp = len(temp2)
        test[i] = temp2[indexTemp-1] 
    for file in os.listdir(sys.argv[1]):
        matches = re.search(pattern, file)
        if matches:
            fileName = matches.group(1) ##### This is causing an error since it's slicing the proj and getting the rest into a hashtable
            if fileName not in list:
                list.append(fileName) ### Now our list is proj....
            if fileName in list:
                dictionary[file] = "assignment"+fileName.strip("proj") 
    for file in os.listdir(sys.argv[1]):
        newFile = file.split(".")
        #if newFile[0].strip("proj") in list:
        if newFile[0] in list: ##### This is the nonstrip version that has the proj*** in it.
            if os.path.isdir(sys.argv[1]+"/assignment"+newFile[0].strip("proj")):
                pass
            else:
                os.system("mkdir "+sys.argv[1]+"/assignment"+newFile[0].strip("proj"))
            shutil.move(sys.argv[1]+"/"+file, sys.argv[1]+"/"+dictionary[file]+"/")
        elif file in test:
            if os.path.isdir(sys.argv[1]+"/assignment"):
                pass
            else:
                os.system("mkdir "+sys.argv[1]+"/assignment") 
            shutil.move(sys.argv[1]+"/"+file, sys.argv[1]+"/assignment/")
        elif not os.path.isdir(sys.argv[1]+"/"+file):
            if os.path.isdir(sys.argv[1]+"/misc"):
                pass
            else:
                os.system("mkdir "+sys.argv[1]+"/misc") 
            shutil.move(sys.argv[1]+"/"+file, sys.argv[1]+"/misc/")

if len(sys.argv) == 2:
    organize()
elif len(sys.argv) == 3:
    organize()
    zipUp = sys.argv[2]

    for file in os.listdir(sys.argv[1]):
        if os.path.isdir(sys.argv[1]+"/"+file):
            if file == "assignment"+zipUp:
                os.system("zip -r "+sys.argv[1]+"/assignment"+zipUp+".zip "+sys.argv[1]+ "/assignment"+zipUp)
                #print("zip -r "+sys.argv[1]+"/assignment"+zipUp+".zip "+sys.argv[1]+ "/assignment"+zipUp)

    #print("Do something else here")    
else:
    print("Incorrect amout of arguments")
